package com.rzx.chatbot;

import android.app.Activity;
import android.os.Bundle;
import android.os.AsyncTask;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private LinearLayout chatLayout;
    private EditText etMessage;
    private Button btnSend;
    private ScrollView scrollView;

    // Chat History
    private List<String> chatHistory = new ArrayList<>();

    // API
    private final String GROQ_API_KEY = "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";
    private final String GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();

        // Welcome message dengan animation
        new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					addBotMessageWithAnimation("Halo! Saya RzX AI v1.3 🚀\nSiap membantu Anda!");
				}
			}, 800);
    }

    private void initViews() {
        chatLayout = (LinearLayout) findViewById(R.id.chatLayout);
        etMessage = (EditText) findViewById(R.id.etMessage);
        btnSend = (Button) findViewById(R.id.btnSend);
        scrollView = (ScrollView) findViewById(R.id.scrollView);

        btnSend.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					sendMessage();
				}
			});

        // Send on Enter
        etMessage.setOnKeyListener(new View.OnKeyListener() {
				@Override
				public boolean onKey(View v, int keyCode, android.view.KeyEvent event) {
					if (event.getAction() == android.view.KeyEvent.ACTION_DOWN && 
						keyCode == android.view.KeyEvent.KEYCODE_ENTER) {
						sendMessage();
						return true;
					}
					return false;
				}
			});
    }

    private void sendMessage() {
        String message = etMessage.getText().toString().trim();
        if (!message.isEmpty()) {
            addUserMessage(message);
            etMessage.setText("");

            // Simpan ke history
            chatHistory.add("You: " + message);

            // Tampilkan typing animation
            showTypingAnimation();

            // Panggil AI
            new GroqApiTask().execute(message);
        }
    }

    // ==================== TYPING ANIMATION ====================
    private Handler typingHandler;
    private Runnable typingRunnable;
    private TextView typingView;

    private void showTypingAnimation() {
        if (typingView != null && typingView.getParent() != null) {
            chatLayout.removeView(typingView);
        }

        typingView = new TextView(this);
        typingView.setText("● RzX AI sedang mengetik");
        typingView.setTextColor(Color.parseColor("#666699"));
        typingView.setPadding(25, 18, 25, 18);
        typingView.setTextSize(14);
        typingView.setId(9999);

        typingView.setBackgroundResource(R.drawable.bg_bot_message);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.gravity = android.view.Gravity.START;
        params.setMargins(0, 8, 60, 8);
        typingView.setLayoutParams(params);

        chatLayout.addView(typingView);
        scrollToBottom();

        // Start dots animation
        typingHandler = new Handler();
        typingRunnable = new Runnable() {
            int dotCount = 0;
            String[] dots = {"●", "●●", "●●●", "●●●●"};

            @Override
            public void run() {
                if (typingView.getParent() != null) {
                    typingView.setText(dots[dotCount % dots.length] + " RzX AI sedang mengetik");
                    dotCount++;
                    typingHandler.postDelayed(this, 400);
                }
            }
        };

        typingHandler.post(typingRunnable);
    }

    private void hideTypingAnimation() {
        if (typingHandler != null && typingRunnable != null) {
            typingHandler.removeCallbacks(typingRunnable);
        }
        if (typingView != null && typingView.getParent() != null) {
            chatLayout.removeView(typingView);
        }
    }

    // ==================== MESSAGE DISPLAY ====================
    private void addUserMessage(String message) {
        TextView tvMessage = new TextView(this);
        tvMessage.setText(message);
        tvMessage.setTextColor(Color.WHITE);
        tvMessage.setBackgroundResource(R.drawable.bg_user_message);
        tvMessage.setPadding(25, 18, 25, 18);
        tvMessage.setTextSize(15);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.gravity = android.view.Gravity.END;
        params.setMargins(60, 8, 0, 8);
        tvMessage.setLayoutParams(params);

        chatLayout.addView(tvMessage);
        scrollToBottom();
    }

    private void addBotMessageWithAnimation(final String message) {
        hideTypingAnimation(); // Hapus typing indicator

        final TextView tvMessage = new TextView(this);
        tvMessage.setText("");
        tvMessage.setTextColor(Color.WHITE);
        tvMessage.setBackgroundResource(R.drawable.bg_bot_message);
        tvMessage.setPadding(25, 18, 25, 18);
        tvMessage.setTextSize(15);
        tvMessage.setLineSpacing(1.2f, 1.2f);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.gravity = android.view.Gravity.START;
        params.setMargins(0, 8, 60, 8);
        tvMessage.setLayoutParams(params);

        chatLayout.addView(tvMessage);
        scrollToBottom();

        // Simpan ke history
        chatHistory.add("AI: " + message);

        // Animasi ketik per karakter
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
				int charIndex = 0;
				final int totalChars = message.length();

				@Override
				public void run() {
					if (charIndex < totalChars) {
						tvMessage.setText(message.substring(0, charIndex + 1));
						charIndex++;

						// Speed typing
						int speed = 30;
						if (totalChars > 100) speed = 20;
						if (totalChars > 300) speed = 10;

						handler.postDelayed(this, speed);
					}
				}
			}, 100);
    }

    // Backward compatibility
    private void addBotMessage(String message) {
        addBotMessageWithAnimation(message);
    }

    private void scrollToBottom() {
        scrollView.post(new Runnable() {
				@Override
				public void run() {
					scrollView.fullScroll(ScrollView.FOCUS_DOWN);
				}
			});
    }

    // ==================== AI GROQ API ====================
    private class GroqApiTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String userMessage = params[0];

            try {
                String jsonRequest = "{" +
                    "\"model\": \"llama-3.1-8b-instant\"," +
                    "\"messages\": [{" +
					"\"role\": \"user\"," +
					"\"content\": \"" + userMessage.replace("\"", "\\\"") + "\"" +
                    "}]," +
                    "\"temperature\": 0.7," +
                    "\"max_tokens\": 1000" +
					"}";

                java.net.URL url = new java.net.URL(GROQ_API_URL);
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Authorization", "Bearer " + GROQ_API_KEY);
                conn.setDoOutput(true);
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(15000);

                java.io.OutputStream os = conn.getOutputStream();
                os.write(jsonRequest.getBytes("UTF-8"));
                os.flush();
                os.close();

                int responseCode = conn.getResponseCode();

                if (responseCode == 200) {
                    java.io.BufferedReader in = new java.io.BufferedReader(
                        new java.io.InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;

                    while ((line = in.readLine()) != null) {
                        response.append(line);
                    }
                    in.close();

                    org.json.JSONObject json = new org.json.JSONObject(response.toString());
                    org.json.JSONArray choices = json.getJSONArray("choices");

                    if (choices.length() > 0) {
                        org.json.JSONObject first = choices.getJSONObject(0);
                        org.json.JSONObject msg = first.getJSONObject("message");
                        return msg.getString("content");
                    }
                } else {
                    return "❌ Error: HTTP " + responseCode;
                }

            } catch (Exception e) {
                return "❌ Error: " + e.getMessage();
            }

            return "❌ No response";
        }

        @Override
        protected void onPostExecute(String result) {
            hideTypingAnimation(); 

            if (result == null || result.isEmpty()) {
                addBotMessage("❌ Tidak ada respon dari AI");
            } else if (result.contains("Error") || result.contains("❌")) {
                addBotMessage("⚠️ " + result + "\n\nCoba lagi dalam beberapa saat.");
            } else {
                addBotMessage(result);
            }
        }
    }

    // ==================== HISTORY FUNCTIONS ====================
    private void saveChatHistory() {
        // Simpan chat history (bisa dikembangkan untuk save ke file)
        if (!chatHistory.isEmpty()) {
            System.out.println("=== CHAT HISTORY ===");
            for (String chat : chatHistory) {
                System.out.println(chat);
            }
            System.out.println("====================");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        saveChatHistory();
    }
}
